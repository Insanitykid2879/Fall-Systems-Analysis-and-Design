from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
import random
import bleak


app = Flask(__name__)
app.config["SECRET_KEY"] = "power_flows_to_the_tne_who_knows_how"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://memory_bank.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


db = SQLAlchemy(app)

#user login system for the app
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(50), nullable=False)


#memory bank model for users 

class MemoryEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question = db.Column(db.String(200), nullable=False)
    answer = db.Column(db.String(50), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))


db.create_all

#the home route

@app.route("/")
def home():
    return render_template("menu.html")


async def connect_bluetooth():
    devices = await bleak.BleakScanner.discover()
    for device in devices:
        print(device)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        new_user = User(username=username, password=password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('login'))
        except:
            return "Error: Username already exists."
    
    return render_template('register.html')

# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        
        if user:
            session['user_id'] = user.id
            return redirect(url_for('home'))
        else:
            return "Invalid username or password."
    
    return render_template('login.html')


@app.route("/answer_checker", methods =["GET","POST"])
def answer_checker():
    if request.method == "POST":
        user_answer = int(request.form["answer"])
        correct_answer = generate_question()
        is_correct = user_answer == correct_answer


        memory_entry = MemoryEntry(question=f"What is {correct_answer}?", answer=str(correct_answer), user_id=session["user_id"])
        db.session.add(memory_entry)
        db.session.commit()

        return render_template("answer_result.html", is_correct=is_correct,  correct_answer=correct_answer)

    return render_template("answer_checker.html")


def generate_question():
    operation = random.choice(["+","-","*","/"])


    num1 = random.randint(1,100)
    num2 = random.randint(1,100)

    if operation == "+":
        question = f"{num1}+{num2}"
        answer = num1 + num2
    
    elif operation == "-":
        #make sure no negative results
        if num1 < num2:
            num1, num2 = num2, num1
        question = f"{num1} - {num2}"
        answer = num1 - num2

    elif operation == "*":
        operation = f"{num1} * {num2}"
        answer = num1 * num2

    elif operation == "/":
        #we need to make sure no fractions or decimals
        while num1 % num2 != 0:
            num1 = random.randint(1, 100)
            num2 = random.randint(1, 100)
        question = f"{num1} / {num2}"
        answer = num1 // num2

    return question, answer

@app.route("/number_guesser", methods=["GET", "POST"])
def number_guesser():
    if request.method == "POST":
        user_guess = int(request.form["guess"])
        correct_number = generate_missing_number_question()
        is_correct = user_guess == correct_number

        memory_entry = MemoryEntry(question=f"What is the missing number in {correct_number}", answer=str(correct_number), user_id=session["user_id"])
        db.session.add(memory_entry)
        db.session.comit()

        return render_template("guess_result.html", is_correct=is_correct, correct_number=correct_number)

    return render_template("number_guesser.html")































